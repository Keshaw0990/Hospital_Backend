package com.hospital.hospital.dto;

import lombok.Data;
import java.time.LocalDate;
@Data
public class PatientDTO {
    private String fullName;
    private String phone;
    private String gender;
    private LocalDate dob;
    private String address;
    private Boolean status;  // Active / Inactive
    private Long stateId;
}
