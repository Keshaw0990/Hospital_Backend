package com.hospital.hospital.service;

import com.hospital.hospital.dto.*;
import com.hospital.hospital.entity.*;
import com.hospital.hospital.repo.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepo;
    private final PatientRepository patientRepo;
    private final DoctorRepository doctorRepo;
    private final StateRepository stateRepo; // ✅ IMPORTANT

    // =========================
    // ENTITY → DTO
    // =========================
    private BookingDTO toDTO(TbBooking b) {

        BookingDTO dto = new BookingDTO();

        // ---------- Booking ----------
        dto.setBookingId(b.getBookingId());
        dto.setBookingDate(b.getBookingDate());
        dto.setStartTime(b.getStartTime());
        dto.setEndTime(b.getEndTime());
        dto.setSlotName(b.getSlotName());
        dto.setBookingNo(b.getBookingNo());
        dto.setStatus(b.getStatus().name());

        // ---------- Patient ----------
        TbPatient p = b.getPatient();
        dto.setPatientId(p.getPatientId());
        dto.setPatientName(p.getFullName());
        dto.setPatientAddress(p.getAddress());
        dto.setPatientPhone(p.getPhone());
        dto.setStateId(p.getStateId());

        // ✅ FETCH STATE NAME MANUALLY
        if (p.getStateId() != null) {
            stateRepo.findById(p.getStateId())
                    .ifPresent(state -> dto.setStateName(state.getStateName()));
        }

        // ---------- Doctor ----------
        dto.setDoctorId(b.getDoctor().getPkDoctorId());
        dto.setDoctorName(b.getDoctor().getFullName());

        return dto;
    }

    // =========================
    // ADD BOOKING
    // =========================
    public BookingDTO addBooking(BookingDTO dto) {

        TbPatient patient = patientRepo.findById(dto.getPatientId())
                .orElseThrow(() -> new RuntimeException("Patient not found"));

        TbDoctor doctor = doctorRepo.findById(dto.getDoctorId())
                .orElseThrow(() -> new RuntimeException("Doctor not found"));

        TbBooking booking = TbBooking.builder()
                .patient(patient)
                .doctor(doctor)
                .bookingDate(dto.getBookingDate())
                .startTime(dto.getStartTime())
                .endTime(dto.getEndTime())
                .slotName(dto.getSlotName())
                .bookingNo("BK-" + UUID.randomUUID().toString().substring(0, 8))
                .status(BookingStatus.BOOKED)
                .build();

        return toDTO(bookingRepo.save(booking));
    }

    // =========================
    // UPDATE BOOKING STATUS
    // =========================
    public BookingDTO updateBooking(Long id, BookingDTO dto) {

        TbBooking booking = bookingRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        booking.setStatus(BookingStatus.valueOf(dto.getStatus()));
        return toDTO(bookingRepo.save(booking));
    }

    // =========================
    // GET ALL BOOKINGS
    // =========================
    public List<BookingDTO> getAllBookings() {
        return bookingRepo.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    // =========================
    // DATE-WISE BOOKING SUMMARY
    // =========================
    public List<BookingCountDTO> getBookingSummary(
            LocalDate startDate,
            LocalDate endDate
    ) {
        return bookingRepo.getBookingCountByDate(startDate, endDate);
    }
}
