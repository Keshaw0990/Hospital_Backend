package com.hospital.hospital.repo;

import com.hospital.hospital.entity.TbPatient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PatientRepository extends JpaRepository<TbPatient, Long> {
}
