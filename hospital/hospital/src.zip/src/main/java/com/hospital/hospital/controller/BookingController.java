package com.hospital.hospital.controller;

import com.hospital.hospital.dto.BookingDTO;
import com.hospital.hospital.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService service;

    @PostMapping("/add")
    public BookingDTO addBooking(@RequestBody BookingDTO dto) {
        return service.addBooking(dto);
    }

    @PutMapping("/update/{id}")
    public BookingDTO updateBooking(@PathVariable Long id, @RequestBody BookingDTO dto) {
        return service.updateBooking(id, dto);
    }

    @GetMapping("/all")
    public List<BookingDTO> getAllBookings() {
        return service.getAllBookings();
    }
}
