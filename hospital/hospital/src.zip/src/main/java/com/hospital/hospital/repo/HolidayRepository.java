package com.hospital.hospital.repo;

import com.hospital.hospital.entity.TbHoliday;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HolidayRepository extends JpaRepository<TbHoliday, Long> {
}
