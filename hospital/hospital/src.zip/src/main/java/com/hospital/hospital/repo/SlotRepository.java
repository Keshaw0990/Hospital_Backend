package com.hospital.hospital.repo;

import com.hospital.hospital.entity.TbSlot;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SlotRepository extends JpaRepository<TbSlot, Long> {
}
