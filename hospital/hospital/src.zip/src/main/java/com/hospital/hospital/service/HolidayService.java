package com.hospital.hospital.service;

import com.hospital.hospital.dto.HolidayDTO;
import com.hospital.hospital.entity.TbDoctor;
import com.hospital.hospital.entity.TbHoliday;
import com.hospital.hospital.repo.DoctorRepository;
import com.hospital.hospital.repo.HolidayRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HolidayService {

    private final HolidayRepository holidayRepo;
    private final DoctorRepository doctorRepo;

    // Convert Entity → DTO
    private HolidayDTO toDTO(TbHoliday h) {
        HolidayDTO dto = new HolidayDTO();
        dto.setHolidayId(h.getHolidayId());
        dto.setHolidayDate(h.getHolidayDate());
        dto.setReason(h.getReason());
        dto.setStatus(h.getStatus());

        if (h.getDoctor() != null) {
            dto.setDoctorId(h.getDoctor().getPkDoctorId());
            dto.setDoctorName(h.getDoctor().getFullName());
        }

        return dto;
    }

    // Add Holiday
    public HolidayDTO addHoliday(HolidayDTO dto) {

        if (dto.getHolidayDate() == null) {
            throw new IllegalArgumentException("holidayDate cannot be null");
        }
        if (dto.getReason() == null || dto.getReason().trim().isEmpty()) {
            throw new IllegalArgumentException("reason cannot be empty");
        }
        if (dto.getDoctorId() == null) {
            throw new IllegalArgumentException("doctorId is required");
        }

        TbDoctor doctor = doctorRepo.findById(dto.getDoctorId())
                .orElseThrow(() -> new RuntimeException("Doctor not found with ID: " + dto.getDoctorId()));

        TbHoliday holiday = TbHoliday.builder()
                .holidayDate(dto.getHolidayDate())
                .reason(dto.getReason())
                .status(dto.getStatus() == null ? Boolean.TRUE : dto.getStatus())
                .doctor(doctor)
                .build();

        return toDTO(holidayRepo.save(holiday));
    }

    // Update Holiday
    public HolidayDTO updateHoliday(Long id, HolidayDTO dto) {

        TbHoliday holiday = holidayRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Holiday not found with ID: " + id));

        if (dto.getHolidayDate() == null) {
            throw new IllegalArgumentException("holidayDate cannot be null");
        }
        if (dto.getReason() == null || dto.getReason().trim().isEmpty()) {
            throw new IllegalArgumentException("reason cannot be empty");
        }

        holiday.setHolidayDate(dto.getHolidayDate());
        holiday.setReason(dto.getReason());
        holiday.setStatus(dto.getStatus());

        TbDoctor doctor = doctorRepo.findById(dto.getDoctorId())
                .orElseThrow(() -> new RuntimeException("Doctor not found with ID: " + dto.getDoctorId()));

        holiday.setDoctor(doctor);

        return toDTO(holidayRepo.save(holiday));
    }

    // Get All
    public List<HolidayDTO> getAll() {
        return holidayRepo.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    // Delete
    public void deleteHoliday(Long id) {
        holidayRepo.deleteById(id);
    }
}
