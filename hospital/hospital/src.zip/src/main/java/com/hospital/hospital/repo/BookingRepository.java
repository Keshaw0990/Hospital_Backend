package com.hospital.hospital.repo;

import com.hospital.hospital.dto.BookingCountDTO;
import com.hospital.hospital.entity.TbBooking;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface BookingRepository extends JpaRepository<TbBooking, Long> {

    // 🔹 DATE-WISE BOOKING COUNT
    @Query("""
        SELECT new com.hospital.hospital.dto.BookingCountDTO(
            b.bookingDate,
            COUNT(b)
        )
        FROM TbBooking b
        WHERE b.bookingDate BETWEEN :startDate AND :endDate
        GROUP BY b.bookingDate
        ORDER BY b.bookingDate
    """)
    List<BookingCountDTO> getBookingCountByDate(
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );
}
